# load NokiaOltDriver class.


from napalm_nokia_olt.nokia_olt import NokiaOltDriver
__all__ = ('NokiaOltDriver',)
